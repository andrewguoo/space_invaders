package invaders.observer;
public interface ScoreObserver {
    void updateScore(int totalScore);
}