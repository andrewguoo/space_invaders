package invaders.observer;
public interface TimeObserver {
    void updateTime(int time);
}